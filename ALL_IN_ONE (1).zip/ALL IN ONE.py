#            ALL IN ONE CALCULATOR 
# ==========================================================
# This program performs arithmetic, trigonometric, logarithmic,
# and health-related calculations.
# ==========================================================

# -------------------- BASIC ARITHMETIC FUNCTIONS --------------------

# Add two numbers
def add(a, b):
    return a + b

# Subtract two numbers
def sub(a, b):
    return a - b

# Multiply two numbers
def mul(a, b):
    return a * b

# Divide two numbers, with zero check
def div(a, b):
    if b == 0:
        return "Error: Division by zero"
    return a / b

# Power function
def power(a, b):
    return a ** b

# Square root function, with negative number check
def sqrt(a):
    if a < 0:
        return "Error: Cannot take square root of negative number"
    return a ** 0.5


# -------------------- TRIGONOMETRIC FUNCTIONS --------------------

PI = 3.141592653589793

# Convert degrees to radians
def to_radians(deg):
    return deg * PI / 180

# Factorial function (used in Taylor series)
def factorial(n):
    fact = 1
    for i in range(1, n + 1):
        fact *= i
    return fact

# Fixed sine function
def sin_deg(angle):
    angle = angle % 360
    if angle == 0 or angle == 180 or angle == 360:
        return 0
    if angle == 90:
        return 1
    if angle == 270:
        return -1
    # Taylor series approximation
    x = to_radians(angle)
    sine = 0
    for n in range(10):
        sine += ((-1) ** n) * (x ** (2*n + 1)) / factorial(2*n + 1)
    return sine

# Fixed cosine function
def cos_deg(angle):
    angle = angle % 360
    if angle == 0 or angle == 360:
        return 1
    if angle == 180:
        return -1
    if angle == 90 or angle == 270:
        return 0
    # Taylor series approximation
    x = to_radians(angle)
    cosine = 0
    for n in range(10):
        cosine += ((-1) ** n) * (x ** (2*n)) / factorial(2*n)     # taylors series used here 
    return cosine

# Fixed tangent function
def tan_deg(angle):
    angle = angle % 360
    if angle == 90 or angle == 270:
        return "Undefined (tan not defined)"
    return sin_deg(angle) / cos_deg(angle)


# -------------------- LOGARITHMIC FUNCTIONS --------------------

# Natural logarithm using series
def ln(x):       # natural log is that how many times i multiply e, by itself to get a number
    if x <= 0:
        return "Error: ln undefined for x ≤ 0"
    y = (x - 1) / (x + 1)
    log_value = 0
    for i in range(1, 20, 2):
        log_value += (y ** i) / i    # mercator series used to converge the values
    return 2 * log_value

# Log base 10
def log10(x):
    if x <= 0:
        return "Error: log undefined for x ≤ 0"
    return ln(x) / 2.302585093     # taking the value of ln by the value of log 10.


# -------------------- HEALTH CALCULATION FUNCTIONS --------------------

# Calculate BMI
def bmi(weight, height):
    return weight / (height * height)

# Give BMI status
def bmi_status(bmi_value):      # it calculates the status of the body,by the value of bmi given
    if bmi_value < 18.5:
        return "Underweight"
    elif bmi_value < 25:
        return "Normal"
    elif bmi_value < 30:
        return "Overweight"
    else:
        return "Obese"

# Calculate Body Fat %
def body_fat(gender, waist, neck, height, hip=None):
    # Convert cm to inches
    waist_in = waist / 2.54
    neck_in = neck / 2.54
    height_in = height / 2.54

    if gender.lower() == "male":
        bf = 86.01 * log10(waist_in - neck_in) - 70.041 * log10(height_in) + 36.76     # US navy formula
    else:
        if hip is None:
            return "Error: Hip measurement required for females"
        hip_in = hip / 2.54
        bf = 163.205 * log10(waist_in + hip_in - neck_in) - 97.684 * log10(height_in) + 78.387    # US navy formula
    return bf

# Give Body Fat status
def body_fat_status(gender, bf):
    if gender.lower() == "male":
        if bf < 6:
            return "Essential fat"
        elif bf < 14:
            return "Athletic"
        elif bf < 18:
            return "Fit"
        elif bf < 25:
            return "Normal range"
        else:
            return "Overfat / High body fat"
    else:
        if bf < 14:
            return "Essential fat"
        elif bf < 21:
            return "Athletic"
        elif bf < 25:
            return "Fit"
        elif bf < 32:
            return "Normal range"
        else:
            return "Overfat / High body fat"


# -------------------- MENU SETUP --------------------

menu = {
    "1": ("Addition", add, 2),
    "2": ("Subtraction", sub, 2),
    "3": ("Multiplication", mul, 2),
    "4": ("Division", div, 2),
    "5": ("Power", power, 2),
    "6": ("Square Root", sqrt, 1),
    "7": ("Sine", sin_deg, 1),
    "8": ("Cosine", cos_deg, 1),
    "9": ("Tangent", tan_deg, 1),
    "10": ("BMI Calculator", bmi, 2),
    "11": ("Body Fat % Calculator", body_fat, 4),
    "12": ("Natural Log (ln)", ln, 1),
    "13": ("Log base 10", log10, 1)
}


# -------------------- MAIN PROGRAM LOOP --------------------

while True:
    print("\n========== SCIENTIFIC CALCULATOR ==========")
    
    # Display menu
    for key in menu:
        print(key, ".", menu[key][0])
    print("0. Exit")

    choice = input("Enter your choice: ")

    if choice == "0":
        print("Thank you for using the calculator!")
        break

    if choice not in menu:
        print("Invalid option, try again.")
        continue

    name, function, arguments = menu[choice]

    # -------------------- BMI CALCULATOR --------------------
    if name == "BMI Calculator":
        weight = float(input("Enter weight (kg): "))
        height_m = float(input("Enter height (m): "))
        bmi_value = function(weight, height_m)
        print("BMI =", round(bmi_value, 2))
        print("Status:", bmi_status(bmi_value))

    # -------------------- BODY FAT CALCULATOR --------------------
    elif name == "Body Fat % Calculator":
        gender = input("Enter gender (Male/Female): ")
        waist = float(input("Enter waist (cm): "))
        neck = float(input("Enter neck (cm): "))
        height = float(input("Enter height (cm): "))
        hip = float(input("Enter hip (cm): ")) if gender.lower() == "female" else None
        bf_value = function(gender, waist, neck, height, hip)
        print("Body Fat % =", round(bf_value, 2))
        print("Status:", body_fat_status(gender, bf_value))

    # -------------------- OTHER OPERATIONS --------------------
    else:
        values = []
        for i in range(arguments):
            value = float(input(f"Enter value {i+1}: "))
            values.append(value)
        result = function(*values)
        print("Result =", result)
